"""Platform and Python version compatibility support."""

import sys


WIN = sys.platform in ('win32', 'cygwin')
